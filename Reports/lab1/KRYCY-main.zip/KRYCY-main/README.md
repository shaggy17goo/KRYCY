# KRYCY
Repository for KRYCY projects on WUT
